# Command Line Interface

::: mkdocs-click
    :module: mkdocs.__main__
    :command: cli
    :prog_name: mkdocs
    :style: table
    :list_subcommands: true
