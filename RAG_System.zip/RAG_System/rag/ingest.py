import os
import re
from typing import List, Dict, Tuple


def _read_text_file(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception:
        return ""


def _iter_files(paths: List[str]) -> List[str]:
    exts = {".txt", ".md"}
    files: List[str] = []
    for p in paths:
        if os.path.isdir(p):
            for root, _, fs in os.walk(p):
                for name in fs:
                    if os.path.splitext(name)[1].lower() in exts:
                        files.append(os.path.join(root, name))
        elif os.path.isfile(p):
            if os.path.splitext(p)[1].lower() in exts:
                files.append(p)
    return files

def _clean_markdown(text: str) -> str:
    # Remove HTML tags
    text = re.sub(r"<[^>]+>", " ", text)
    # Convert images ![alt](url) -> alt
    text = re.sub(r"!\[([^\]]*)\]\([^\)]*\)", r"\1", text)
    # Convert links [text](url) -> text
    text = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", text)
    # Remove Markdown anchors in headings: ### Title {#anchor}
    text = re.sub(r"\s*\{#.+?\}\s*$", "", text, flags=re.MULTILINE)
    # Normalize list markers
    text = re.sub(r"^\s*[-*+]\s+", "- ", text, flags=re.MULTILINE)
    # Collapse multiple backticks but keep code content
    text = text.replace("```", "\n")
    text = text.replace("`", "")
    # Normalize whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _clean_plain(text: str) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _chunk_words(text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
    words = text.split()
    if not words:
        return []
    chunks: List[str] = []
    i = 0
    while i < len(words):
        chunk = words[i:i + chunk_size]
        chunks.append(" ".join(chunk))
        if i + chunk_size >= len(words):
            break
        i += max(1, chunk_size - overlap)
    return chunks


def _split_markdown_sections(text: str) -> List[Tuple[str, str]]:
    # Returns list of (heading_path, section_text)
    lines = text.splitlines()
    sections: List[Tuple[str, str]] = []
    current_heading_stack: List[Tuple[int, str]] = []
    buf: List[str] = []

    def push_section():
        if buf:
            heading_path = " > ".join(h for _, h in current_heading_stack)
            sections.append((heading_path, "\n".join(buf).strip()))
            buf.clear()

    for line in lines:
        m = re.match(r"^(#{1,6})\s+(.*)", line)
        if m:
            # Start new section
            push_section()
            level = len(m.group(1))
            title = re.sub(r"\s*\{#.+\}$", "", m.group(2)).strip()
            # Adjust heading stack
            while current_heading_stack and current_heading_stack[-1][0] >= level:
                current_heading_stack.pop()
            current_heading_stack.append((level, title))
        else:
            buf.append(line)
    push_section()
    return sections


def _chunk_markdown(text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
    chunks: List[str] = []
    for heading_path, section in _split_markdown_sections(text):
        cleaned = _clean_markdown(section)
        if not cleaned:
            continue
        base = f"{heading_path}: " if heading_path else ""
        for c in _chunk_words(cleaned, chunk_size=chunk_size, overlap=overlap):
            chunks.append(base + c)
    # Fallback if no headings detected
    if not chunks:
        cleaned = _clean_markdown(text)
        chunks = _chunk_words(cleaned, chunk_size=chunk_size, overlap=overlap)
    return chunks


def ingest_paths(paths: List[str]) -> List[Dict[str, str]]:
    docs: List[Dict[str, str]] = []
    for fp in _iter_files(paths):
        text = _read_text_file(fp)
        if not text:
            continue
        ext = os.path.splitext(fp)[1].lower()
        if ext == ".md":
            chunks = _chunk_markdown(text, chunk_size=550, overlap=50)
        else:
            cleaned = _clean_plain(text)
            chunks = _chunk_words(cleaned, chunk_size=550, overlap=50)
        for idx, chunk in enumerate(chunks):
            docs.append({"id": f"{fp}#chunk{idx}", "text": chunk})
    return docs
