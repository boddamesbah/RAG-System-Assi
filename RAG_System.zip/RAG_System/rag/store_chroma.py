import os
from typing import List, Tuple

import chromadb
from chromadb.utils import embedding_functions


STORE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".chroma_store")
COLLECTION_NAME = "mkdocs"


def _get_client() -> chromadb.PersistentClient:
    os.makedirs(STORE_DIR, exist_ok=True)
    return chromadb.PersistentClient(path=STORE_DIR)


def _get_collection():
    client = _get_client()
    model_name = os.getenv("EMBEDDING_MODEL", "BAAI/bge-small-en-v1.5")
    embedder = None
    # Try Chroma's FastEmbed embedding function if available
    if hasattr(embedding_functions, "FastEmbedEmbeddingFunction"):
        embedder = embedding_functions.FastEmbedEmbeddingFunction(model_name=model_name)
    else:
        # Fallback: build a local fastembed wrapper
        try:
            from fastembed import TextEmbedding  # type: ignore

            class _FastEmbedWrapper:
                def __init__(self, name: str):
                    self._model = TextEmbedding(model_name=name)

                def __call__(self, input):
                    # Returns a list of list[float]
                    return [list(vec) for vec in self._model.embed(input)]

            embedder = _FastEmbedWrapper(model_name)
        except Exception:
            # Last resort: use Chroma's DefaultEmbeddingFunction
            embedder = embedding_functions.DefaultEmbeddingFunction()
    try:
        col = client.get_collection(COLLECTION_NAME)
        # In case collection exists without embedding function, recreate
        if getattr(col, "_embedding_function", None) is None:
            client.delete_collection(COLLECTION_NAME)
            col = client.create_collection(COLLECTION_NAME, embedding_function=embedder)
        return col
    except Exception:
        return client.create_collection(COLLECTION_NAME, embedding_function=embedder)


def add_documents(docs: List[dict]) -> int:
    if not docs:
        return 0
    col = _get_collection()
    ids = [d["id"] for d in docs]
    texts = [d["text"] for d in docs]
    metadatas = [{"source": d["id"].split("#")[0]} for d in docs]
    # Upsert to allow re-ingestion
    col.upsert(ids=ids, documents=texts, metadatas=metadatas)
    return len(ids)


def search(query: str, top_k: int = 5) -> List[Tuple[str, str, float]]:
    col = _get_collection()
    res = col.query(query_texts=[query], n_results=top_k)
    ids = res.get("ids", [[]])[0]
    docs = res.get("documents", [[]])[0]
    dists = res.get("distances", [[]])[0]
    out: List[Tuple[str, str, float]] = []
    for i, t, d in zip(ids, docs, dists):
        # Convert cosine distance to similarity
        try:
            sim = 1.0 - float(d)
        except Exception:
            sim = 0.0
        out.append((i, t, sim))
    return out


def count_documents() -> int:
    try:
        col = _get_collection()
        return int(col.count())
    except Exception:
        return 0


def reset_store() -> None:
    client = _get_client()
    try:
        client.delete_collection(COLLECTION_NAME)
    except Exception:
        pass
    # Recreate collection so it's ready for use
    _get_collection()
