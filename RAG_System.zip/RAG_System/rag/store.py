import json
import os
from typing import List, Tuple

import joblib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


STORE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".rag_store")
VECT_FILE = os.path.join(STORE_DIR, "vectorizer.joblib")
MATRIX_FILE = os.path.join(STORE_DIR, "matrix.joblib")
IDS_FILE = os.path.join(STORE_DIR, "ids.json")
TEXTS_FILE = os.path.join(STORE_DIR, "texts.json")


def _ensure_dir() -> None:
    os.makedirs(STORE_DIR, exist_ok=True)


def _new_vectorizer() -> TfidfVectorizer:
    return TfidfVectorizer(ngram_range=(1, 2), max_df=0.9, min_df=1)


def load_store() -> Tuple[TfidfVectorizer, np.ndarray, List[str], List[str]]:
    if not os.path.exists(VECT_FILE) or not os.path.exists(MATRIX_FILE) or not os.path.exists(IDS_FILE) or not os.path.exists(TEXTS_FILE):
        return _new_vectorizer(), np.zeros((0, 0)), [], []
    vect: TfidfVectorizer = joblib.load(VECT_FILE)
    X = joblib.load(MATRIX_FILE)
    with open(IDS_FILE, "r", encoding="utf-8") as f:
        ids = json.load(f)
    with open(TEXTS_FILE, "r", encoding="utf-8") as f:
        texts = json.load(f)
    return vect, X, ids, texts


def save_store(vect: TfidfVectorizer, X, ids: List[str], texts: List[str]) -> None:
    _ensure_dir()
    joblib.dump(vect, VECT_FILE)
    joblib.dump(X, MATRIX_FILE)
    with open(IDS_FILE, "w", encoding="utf-8") as f:
        json.dump(ids, f)
    with open(TEXTS_FILE, "w", encoding="utf-8") as f:
        json.dump(texts, f)


def add_documents(docs: List[dict]) -> int:
    vect, X, ids, texts = load_store()
    new_ids = [d["id"] for d in docs]
    new_texts = [d["text"] for d in docs]
    ids = ids + new_ids
    texts = texts + new_texts
    vect = _new_vectorizer()
    X = vect.fit_transform(texts)
    save_store(vect, X, ids, texts)
    return len(new_ids)


def search(query: str, top_k: int = 5) -> List[Tuple[str, str, float]]:
    vect, X, ids, texts = load_store()
    if X.shape[0] == 0:
        return []
    q = vect.transform([query])
    sims = cosine_similarity(q, X).ravel()
    idxs = np.argsort(-sims)[:top_k]
    return [(ids[i], texts[i], float(sims[i])) for i in idxs]
