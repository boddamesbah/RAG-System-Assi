from rag.rag import rag_answer

questions = [
    "How do I install mkdocs?",
    "How do I serve docs locally during development?",
    "How do I configure the theme and site_name in mkdocs.yml?",
    "How do I define navigation in mkdocs.yml?",
    "How do I deploy mkdocs to GitHub Pages?",
]

for q in questions:
    answer, ctx = rag_answer(q, top_k=3)
    print(f"Q: {q}")
    for i, (doc_id, text, score) in enumerate(ctx, start=1):
        print(f"CTX{i} score={score:.3f} id={doc_id}")
        t = (text or "").replace("\n", " ")
        print(t[:600])
        print("")
    print("---")
