import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict
from dotenv import load_dotenv
from rag.ingest import ingest_paths
from rag.rag import ingest_docs, rag_answer
from rag.store_chroma import search as vector_search
from rag.store_chroma import count_documents, reset_store

load_dotenv()


class IngestRequest(BaseModel):
    paths: Optional[List[str]] = None
    docs: Optional[List[Dict[str, str]]] = None


class QueryRequest(BaseModel):
    question: str
    top_k: int = 5


app = FastAPI()

# CORS (allow all for local testing/submission)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/ingest")
async def ingest(req: IngestRequest):
    docs = []
    if req.paths:
        docs.extend(ingest_paths(req.paths))
    if req.docs:
        for d in req.docs:
            if "id" in d and "text" in d:
                docs.append({"id": d["id"], "text": d["text"]})
    if not docs:
        return {"ingested": 0}
    n = ingest_docs(docs)
    return {"ingested": n}


@app.post("/query")
async def query(req: QueryRequest):
    answer, ctx = rag_answer(req.question, req.top_k)
    return {"answer": answer, "context": ctx}


class SearchRequest(BaseModel):
    query: str
    top_k: int = 5


@app.post("/search")
async def search(req: SearchRequest):
    results = vector_search(req.query, top_k=req.top_k)
    return {"results": results}


@app.get("/stats")
async def stats():
    return {"documents": count_documents()}


class MkdocsIngestRequest(BaseModel):
    path: Optional[str] = None  # default to env MKDOCS_DOCS_PATH or ./mkdocs/docs


@app.post("/ingest_mkdocs")
async def ingest_mkdocs(req: MkdocsIngestRequest):
    base = req.path or os.getenv("MKDOCS_DOCS_PATH", "./mkdocs/docs")
    docs = ingest_paths([base])
    if not docs:
        return {"ingested": 0, "path": base}
    n = ingest_docs(docs)
    return {"ingested": n, "path": base}


@app.post("/reset")
async def reset():
    reset_store()
    return {"reset": True}
