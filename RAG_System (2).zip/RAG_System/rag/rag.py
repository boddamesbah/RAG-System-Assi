import os
from typing import List, Dict, Tuple

from .store_chroma import add_documents as _add_documents
from .store_chroma import search as _search
from dotenv import load_dotenv

load_dotenv()


def ingest_docs(docs: List[Dict[str, str]]) -> int:
    valid = [d for d in docs if isinstance(d, dict) and "id" in d and "text" in d and d["text"]]
    if not valid:
        return 0
    return _add_documents(valid)


def _format_context(ctx: List[Tuple[str, str, float]]) -> str:
    lines = []
    for _id, text, score in ctx:
        lines.append(f"[score={score:.3f}] {_id}: {text}")
    return "\n".join(lines)


def _try_openai(question: str, contexts: List[str]) -> str:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return ""
    prompt = (
        "You are a helpful assistant. Answer the user's question using ONLY the provided context. "
        "If the answer is not in the context, say you don't know.\n\n" 
        f"Question: {question}\n\nContext:\n" + "\n\n".join(f"- {c}" for c in contexts)
    )
    # Try new SDK first
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        resp = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )
        return resp.choices[0].message.content.strip()
    except Exception:
        pass
    # Fallback to legacy API
    try:
        import openai  # type: ignore
        openai.api_key = api_key
        resp = openai.ChatCompletion.create(
            model=os.getenv("OPENAI_MODEL", "gpt-3.5-turbo"),
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )
        return resp["choices"][0]["message"]["content"].strip()
    except Exception:
        return ""


def rag_answer(question: str, top_k: int = 5):
    results = _search(question, top_k=top_k)
    contexts = [t for _, t, _ in results]
    if not results:
        return "No documents indexed yet.", []
    gen = _try_openai(question, contexts)
    if gen:
        return gen, results
    joined = "\n---\n".join(contexts)
    return f"Context-only answer (LLM disabled):\n{joined}", results
