from .templates import url_filter  # noqa: F401 - legacy re-export
