# RAG_System

Minimal Retrieval-Augmented Generation (RAG) service using FastAPI + Chroma + Sentence-Transformers, tailored for mkdocs user guides.

## Features
- Ingest `.md`/`.txt` docs from local paths/folders, or raw docs via API.
- Markdown-aware chunking (heading-structured) and cleaning.
- Embeddings via Sentence-Transformers (default: `all-MiniLM-L6-v2`).
- Vector DB: Chroma (persistent local store).
- Optional answer generation via OpenAI if `OPENAI_API_KEY` is set; otherwise returns best-matching context.

## Quickstart
1) Create venv and install deps (Windows PowerShell):
```
py -m venv .venv
.\.venv\Scripts\pip install -r requirements.txt
```
2) Run API:
```
.\.venv\Scripts\uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
3) Health check:
```
curl http://127.0.0.1:8000/health
```

## Ingest mkdocs user guides
Clone the mkdocs repository (or point to an existing clone):
```
git clone https://github.com/mkdocs/mkdocs.git
```
Ingest the user guides from the repo (the docs live under `mkdocs/docs`):
```
curl -X POST http://127.0.0.1:8000/ingest \
  -H "Content-Type: application/json" \
  -d '{"paths": ["./mkdocs/docs"]}'
```
- Or direct docs:
```
curl -X POST http://127.0.0.1:8000/ingest \
  -H "Content-Type: application/json" \
  -d '{"docs": [{"id": "d1", "text": "Python is a programming language."}]}'
```

## Query
```
curl -X POST http://127.0.0.1:8000/query \
  -H "Content-Type: application/json" \
  -d '{"question": "How do I configure a theme in mkdocs?", "top_k": 5}'
```
Response includes `answer` and `context` (list of matched chunks with scores).

## Environment
Create `.env` at project root (optional):
```
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-4o-mini
EMBEDDING_MODEL=all-MiniLM-L6-v2
```
Without an API key, the service returns a context-only answer.

## Data store
- Chroma persistent store is created under `.chroma_store/`.
- Re-ingesting upserts new chunks; re-ingesting existing ids replaces them.

## Notes
- Supported file types: `.txt`, `.md`.
- Chunking: heading-aware Markdown sections, then ~550-word chunks with 50-word overlap. Non-Markdown files are split into ~550-word chunks.
- Cleaning: strips HTML, link syntax, image syntax, code fences/backticks, normalizes whitespace.

## Next
- Evaluation harness (RAGAS or simple precision@k).
- Optional UI (simple chat).
- Dockerfile / deployment.

## API Endpoints
- GET `/health` → `{ "status": "ok" }`
- GET `/stats` → `{ "documents": <int> }`
- POST `/ingest` → body: `{ "paths": ["<dir>"], "docs": [{"id": "..", "text": ".."}] }` → `{ "ingested": <int> }`
- POST `/ingest_mkdocs` → body: `{ "path": "./mkdocs/docs" }` (optional; defaults to env `MKDOCS_DOCS_PATH` or `./mkdocs/docs`) → `{ "ingested": <int>, "path": "..." }`
- POST `/search` → body: `{ "query": "...", "top_k": 5 }` → `{ "results": [[id, text, score], ...] }`
- POST `/query` → body: `{ "question": "...", "top_k": 5 }` → `{ "answer": str, "context": [[id, text, score], ...] }`

Example (PowerShell):
```
$q = @{ query = "How do I install mkdocs?"; top_k = 3 } | ConvertTo-Json
Invoke-RestMethod -Uri http://127.0.0.1:8000/search -Method Post -ContentType 'application/json' -Body $q | ConvertTo-Json
```
